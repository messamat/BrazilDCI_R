library(testthat)
library(bigassertr)

test_check("bigassertr")
