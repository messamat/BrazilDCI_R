# rmio
R package providing 'mio' header files (https://github.com/mandreyel/mio)
