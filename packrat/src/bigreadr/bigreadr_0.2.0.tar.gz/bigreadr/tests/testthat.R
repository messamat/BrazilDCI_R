library(testthat)
library(bigreadr)

test_check("bigreadr")
