#' @useDynLib bigreadr, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom bigassertr message2 warning2 stop2 assert_exist assert_int assert_pos
#' @keywords internal
"_PACKAGE"
