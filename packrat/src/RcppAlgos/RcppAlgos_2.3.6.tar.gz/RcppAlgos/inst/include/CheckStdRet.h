#ifndef CHECK_STD_RET_H
#define CHECK_STD_RET_H

#include <Rcpp.h>

bool CheckConstrnd(SEXP f1, SEXP f2, SEXP Rtarget);

#endif
