library(testthat)
library(bigparallelr)

test_check("bigparallelr")
